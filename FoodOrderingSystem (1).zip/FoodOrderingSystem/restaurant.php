<?php
session_start();
if(!isset($_SESSION['username'])){
    header("location: login.php");
    exit();
}
if($_SESSION["admin"]=='YES'){
    header("location: sales.php");
    exit();
}
require_once "config.php";

/*
$cartItemN = [];
$cartItemQ = [];
$cartItemP = [];
$err = $addr = "";
if($_SERVER['REQUEST_METHOD']=="POST"){
    if(isset($_POST['ordernow'])){
        $vwhp = $_POST['vwhp'];
        $nvwhp = $_POST['nvwhp'];
        $vwpj = $_POST['vwpj'];
        $nvwpj = $_POST['nvwpj'];
        $vkng = $_POST['vkng'];
        $nvkng = $_POST['nvkng'];
        if($vwhp>0){
            $cartItemN[] = "Whopper Veg";
            $cartItemQ[] = $vwhp;
            $cartItemP[] = $vwhp*$Pvwhp;
        }
        if($nvwhp>0){
            $cartItemN[] = "Whopper Non-Veg";
            $cartItemQ[] = $nvwhp;
            $cartItemP[] = $nvwhp*$Pnvwhp;
        }
        if($vwpj>0){
            $cartItemN[] = "Whopper Jr. Veg";
            $cartItemQ[] = $vwpj;
            $cartItemP[] = $vwpj*$Pvwpj;
        }
        if($nvwpj>0){
            $cartItemN[] = "Whopper Jr. Non-Veg";
            $cartItemQ[] = $nvwpj;
            $cartItemP[] = $nvwpj*$Pnvwpj;
    
        }
        if($vkng>0){
            $cartItemN[] = "King Veg";
            $cartItemQ[] = $vkng;
            $cartItemP[] = $vkng*$Pvkng;
        }
        if($nvkng>0){
            $cartItemN[] = "King Non-Veg";
            $cartItemQ[] = $nvkng;
            $cartItemP[] = $nvkng*$Pnvkng;
        }
    }
}
    
$totPrice = $tax = 0;
foreach($cartItemP as $pr){
    $totPrice = $totPrice + $pr;
}
if(($totPrice>0)){
    $tax = $totPrice*(8/100);
    $_SESSION["tax"] = $tax;
    $totPrice = $totPrice + $tax;
    $_SESSION["netAmount"] = $totPrice;
    if(empty(trim($_POST['addr']))){
        $err = "*Please enter Delivery Address";
    }
    else{
        $_SESSION["addr"] = $_POST['addr'];
        header("location: cart.php");
    }
    
    $_SESSION["cartItemN"] = $cartItemN;
    $_SESSION["cartItemQ"] = $cartItemQ;
    $_SESSION["cartItemP"] = $cartItemP;
}
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Food Ordering System</title>
    <link rel="icon" href="Assets/logo.png">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="nav-container">
        <ul>
            <ul>
                <li class="brand"><img src="Assets/logo.png" alt="Music">Foogle</li>
            </ul>
            <ul class="right-ul">
                <li><a href="index.php">Home</a></li>
                <li><a id="active" href="restaurant.php">Restaurant</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </ul>
    </nav>
    <div class="container">
        <form action="" method="post">
            <div class="restau-items">
                <div class="restau">
                    <div class="restau-pic">
                        <img src="Assets/Restaurant/rest.jpg" alt="wh">
                    </div>
                    <div class="restau-input">
                        <div class="flex1">
                            <button class="orderbtn" name="ordernow" type="button"><a href="rest1.php">Order Now</a></button>
                        </div>
                        <div class="flex2">
                                <div><input class="table-qua" type="number" name="f3tab" id="f3tab" min="0" max="15" value="0"></div>
                                <div><button class="tabbtn" name="booktablef3" id="booktablef3" type="submit">Book a Table</button></div>
                                <div class="tabsta"><span style="color: red;">
                                    <?php
                                            if(array_key_exists('booktablef3', $_POST)) {
                                                $f3tab = $_POST['f3tab'];
                                                button1($f3tab);
                                            }
                                            function button1($f3tab) {
                                                if($f3tab>0)
                                                    if($f3tab==1)
                                                        echo $f3tab." table has been reserved!";
                                                    else        
                                                        echo $f3tab." tables have been reserved!";
                                            }
                                    ?>
                                </span></div>
                        </div>
                        <!--<input class="food-quantity" style="border: 2px solid green" type="number" name="vwhp" id="vwhp" min="0" max="10" value="0">
                        <input class="food-quantity" style="border: 2px solid red" type="number" name="nvwhp" id="nvwhp" min="0" max="10" value="0">
                 --></div>
                    <div class="restau-details">
                        <h3>f3 cafe & bistro</h3>
                        <ul>
                            <li>Rating: 4.4</li>
                            <li>Review: One of the best restaurant</li>
                        </ul>
                    </div>
                </div>
                <div class="restau">
                    <div class="restau-pic">
                        <img src="Assets/Restaurant/rest2.jpg" alt="whj">
                    </div>
                    <div class="restau-input">
                        <div class="flex1">
                            <button class="orderbtn" name="ordernow" type="button"><a href="rest2.php">Order Now</a></button>
                        </div>
                        <div class="flex2">
                                <div><input class="table-qua" type="number" name="baytab" id="baytab" min="0" max="15" value="0"></div>
                                <div><button class="tabbtn" name="booktablebay" id="booktable" type="submit">Book a Table</button></div>
                                <div class="tabsta"><span style="color: red;">
                                    <?php
                                            if(array_key_exists('booktablebay', $_POST)) {
                                                $baytab = $_POST['baytab'];
                                                button2($baytab);
                                            }
                                            function button2($baytab) {
                                                if($baytab>0)
                                                    if($baytab==1)
                                                        echo $baytab." table has been reserved!";
                                                    else        
                                                        echo $baytab." tables have been reserved!";
                                            }
                                    ?>
                                </span></div>
                        </div>
                     <!--   <input class="food-quantity" style="border: 2px solid green" type="number" name="vwpj" id="vwpj" min="0" max="10" value="0">
                        <input class="food-quantity" style="border: 2px solid red" type="number" name="nvwpj" id="nvwpj" min="0" max="10" value="0">
--></div>
                    <div class="restau-details">
                        <h3>Bayleaf Bistro</h3>
                        <ul>
                            <li>Rating: 4.0</li>
                            <li>Review: Best place for Pizzas</li>
                        </ul>
                    </div>
                </div>
                <div class="restau">
                    <div class="restau-pic">
                        <img src="Assets/Restaurant/rest3.jpg" alt="kn">
                    </div>
                    <div class="restau-input">
                        <div class= "flex1">
                            <button class="orderbtn" name="ordernow" type="button"><a href="rest3.php">Order Now</a></button>
                        </div>
                        <div class= "flex2">
                            <div><input class="table-qua" type="number" name="grtab" id="grtab" min="0" max="15" value="0"></div>
                            <div><button class="tabbtn" name="booktablegr" id="booktable" type="submit">Book a Table</button></div>
                            <div class="tabsta"><span style="color: red;">
                                    <?php
                                            if(array_key_exists('booktablegr', $_POST)) {
                                                $grtab = $_POST['grtab'];
                                                button3($grtab);
                                            }
                                            function button3($grtab) {
                                                    if($grtab==1)
                                                        echo $grtab." table has been reserved!";
                                                    else        
                                                        echo $grtab." tables have been reserved!";
                                            }
                                    ?>
                                </span></div>                 
                        </div>
                     <!--   <input class="food-quantity" style="border: 2px solid green" type="number" name="vkng" id="vkng" min="0" max="10" value="0">
                        <input class="food-quantity" style="border: 2px solid red" type="number" name="nvkng" id="nvkng" min="0" max="10" value="0">
-->                 </div>
                    <div class="restau-details">
                        <h3>Groove 9</h3>
                        <ul>
                            <li>Rating: 4.2</li>
                            <li>Review: Nice ambience.</li>
                        </ul>
                    </div>
                </div>
                <!--<div class="restau">
                    <div class="restau-pic">
                        <img src="Assets/Store/Rebel.png" alt="rb">
                    </div>
                    <div class="restau-input">
                        <input class="food-quantity" type="number" name="vrbl" id="vrbl" min="0" max="10" value="0">
                        <input class="food-quantity" type="number" name="nvrbl" id="nvrbl" min="0" max="10" value="0">
                    </div>
                    <div class="restau-details">
                        <h3>Rebel</h3>
                        <ul>
                            <li>Veg: Rs. 120</li>
                            <li>Non-Veg: Rs. 150</li>
                        </ul>
                    </div>
                </div>
                <div class="restau">
                    <div class="restau-pic">
                        <img src="Assets/Store/Shake.png" alt="sh">
                    </div>
                    <div class="restau-input">
                        <input class="food-quantity" type="number" name="shk" id="shk" min="0" max="10" value="0">
                    </div>
                    <div class="restau-details">
                        <h3>Shake</h3>
                        <ul>
                            <li>Rs. 100</li>
                        </ul>
                    </div>
                </div>
                <div class="restau">
                    <div class="restau-pic">
                        <img src="Assets/Store/Meal.png" alt="ml">
                    </div>
                    <div class="restau-input">
                        <input class="food-quantity" type="number" name="vml" id="vml" min="0" max="10" value="0">
                        <input class="food-quantity" type="number" name="nvml" id="nvml" min="0" max="10" value="0">
                    </div>
                    <div class="restau-details">
                        <h3>Meal</h3>
                        <ul>
                            <li>Veg: Rs. 250</li>
                            <li>Non-Veg: Rs. 280</li>
                        </ul>
                    </div>
                </div>-->
               <!-- <div class="address" style="margin: 3% 8%">
                    <div>
                        Delivery Address: <span style="color: red;"><?php echo $err;?></span>
                    </div><br>
                    <div>
                        <input class="delivery-address" type="text" name="addr" id="addr" style="width: 50%; font-size: 16px; padding: 3px;" placeholder="221b Baker St, London NW1 6XE">
                    </div>
                </div>
                <div class="to-cart">
                    <button name="ordernow" type="submit">Add to Cart</button>
                </div>
            </div>-->
        </form>
    </div>

    <script src="https://kit.fontawesome.com/6f42fc440c.js" crossorigin="anonymous"></script>
    <script src="script.js"></script>
</body>
</html>