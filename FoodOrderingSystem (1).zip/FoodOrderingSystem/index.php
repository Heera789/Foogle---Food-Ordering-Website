<?php
session_start();
require_once "config.php";
if(!(isset($_SESSION['admin']))){
    $_SESSION['admin'] = "NIL";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Food Ordering System</title>
    <link rel="icon" href="Assets/logo.png">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <nav class="nav-container">
        <ul>
            <ul>
                <li class="brand"><img src="Assets/logo.png" alt="Music">Foogle</li>
            </ul>
            <ul class="right-ul">
                <li><a id="active" href="index.php">Home</a></li>
                <?php if($_SESSION["admin"]=='YES'): ?>
                <li><a href="sales.php">Sales</a></li>
                <li><a href="burgers.php">Burgers</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logout.php">Logout</a></li>
                <?php elseif ($_SESSION["admin"]=='NIL'):?>
                <li><a href="register.php">Register</a></li>
                <li><a href="login.php">Login</a></li>
                <?php else:?>
                  <li><a href="restaurant.php">Restaurant</a></li>
                <li><a href="cart.php">Cart</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logout.php">Logout</a></li>
                <?php endif;?>
            </ul>
        </ul>
    </nav>
    <div class="container">
        <section class="banner">
            <img src="Assets/bg4.jpg" alt="1">
        </section>
        <section class="slogan">
            <h1>Want Quality Meal?<br>Order Now!<br>Or Book a Table!</h1>
        </section>
        <section class="speciality">
            <div class="speciality-content">
                <div class="speciality-pic">
                    <img src="Assets/Restaurant/rest.jpg" alt="b">
                    <img src="Assets/Restaurant/rest2.jpg" alt="b">
                    <img src="Assets/Restaurant/rest3.jpg" alt="b">
                </div>
                <div class="speciality-head">
                    <h2>Our Restaraunts</h2>
                </div>
            </div>
            <div class="speciality-content">
                <div class="speciality-head">
                    <h2>Featured Food</h2>
                </div>
                <div class="speciality-pic">
                    <img src="Assets/food.jpeg" alt="d">                         
                    <img src="Assets/food2.jpeg" alt="d">
                    <img src="Assets/food3.jpeg" alt="d">
                </div>
            </div>
        </section>
    </div>
    
    
    <div class="footer">
        <div class="contain">
            <div class="col">
                <h1>Developers</h1>
                <ul>
                    <li>Shruti</li>
                    <li>Heera</li>
                    <li>Vaishnavi</li>
                    <li>Yashaswini</li>
                    
                </ul>
            </div>
            <div class="col">
                <h1>Restaraunt</h1>
                <ul>
                    <li></li>
                    <li>f3 cafe & bistro</li>
                    <li>Bayleaf Bistro</li>
                    <li>Groove 9</li>
                </ul>
            </div>
            <div class="col">
                <h1>About</h1>
                <ul>
                    <li>Terms</li>
                    <li>Mission</li>
                    <li>Services</li>
                    <li>Education</li>
                    <li>Get in touch</li>
                </ul>
            </div>
            
            <div class="col">
                <h1>Support</h1>
                <ul>
                    <li>Contact us</li>
                    <li>Send Email</li>
                    <li>Buy a phone</li>
                </ul>
            </div>
            <div class="col social">
                <h1>Social</h1>
                <ul>
                    <li><img src="Assets/facebook.jpeg" width="32" style="width: 32px;"></li>
                    <li><img src="Assets/instagram.jpeg" width="32" style="width: 32px;"></li>
                    <li><img src="Assets/twitter.jpeg" width="32" style="width: 32px;"></li>

                </ul>
            </div>
            <div class="clearfix"></div>
            <footer class="foot">
                <p class="footp"> Copyright © 2020 - All rights Reserved - Designed by Foogle Community </p>
            </footer>
        </div>
    </div>
    
    
    <script src="https://kit.fontawesome.com/6f42fc440c.js" crossorigin="anonymous"></script>
    <script src="script.js"></script>
</body>
</html>